//
//  main.m
//  kview
//
//  Created by Robert Pointon on 18/11/2010.
//  Copyright 2010 fernlightning. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
